package com.interfaces;

public class Parrot extends Bird implements Flyable, Talkable {

	public Parrot(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void talk() {
		System.out.println(name+ " Talks like human");
	}

	@Override
	public void fly() {
		System.out.println(name+" flys low");
	}

}
