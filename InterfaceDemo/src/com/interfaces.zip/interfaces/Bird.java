package com.interfaces;

public class Bird {
	String name;
	
	public Bird(String name) {
		super();
		this.name = name;
	}

	void getDetails(){
		System.out.println("Name "+name);
	}

}
