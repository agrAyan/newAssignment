package com.interfaces;

public class InterDemo {
	public static void main(String[] args) {
		
		Bird bird = new Parrot("parrot");
		bird.getDetails();
		Flyable ref = (Flyable)bird;
		ref.fly();
		Talkable tk =(Talkable)bird;
		tk.talk();
		System.out.println();
		Bird bird1 = new Duck("duck");
		bird1.getDetails();
		Flyable ref1 = (Flyable)bird1;
		ref1.fly();
		Swimmable tk1 =(Swimmable)bird1;
		tk1.swim();
		
	}

}
