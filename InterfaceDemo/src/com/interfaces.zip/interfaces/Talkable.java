package com.interfaces;

public interface Talkable {
	void talk();

}
