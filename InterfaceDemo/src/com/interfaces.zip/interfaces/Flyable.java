package com.interfaces;

public interface Flyable {
	void fly();

}
