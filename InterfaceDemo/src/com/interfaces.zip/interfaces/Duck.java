package com.interfaces;

public class Duck extends Bird implements Flyable, Swimmable {

	@Override
	public void swim() {
		System.out.println(name+ " swims lika a fish");
	}

	@Override
	public void fly() {
		System.out.println(name+" flys low");
	}

	public Duck(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
