package com.interfaces;

public interface Swimmable {
	void swim();

}
