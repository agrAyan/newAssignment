package com.interfaces1;

public class InEmployee implements Recreation{
	String name;
	double salary;

	
	public InEmployee(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}


	void getDetails(){
		System.out.println("Name "+name);
		System.out.println("Salary "+salary);
	}


	@Override
	public void theatreClub() {
		System.out.println("Theatre for acting BY "+Recreation.PROVIDER);
	}


	@Override
	public void musicClub() {
		System.out.println("music orchestra group BY "+Recreation.PROVIDER);
	}

}
