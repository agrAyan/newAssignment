package com.interfaces1;

public class Techy implements Gamer{

	@Override
	public void theatreClub() {
		System.out.println("Theatre for monoacting");
	}

	@Override
	public void musicClub() {
		System.out.println("Western music only");
	}

	@Override
	public void outdoorGames() {
		System.out.println("Hockey");
	}

	@Override
	public void indoorGames() {
		System.out.println("Table tennis");
	}

}
