package com.interfaces1;

public interface Recreation {
	String PROVIDER = "ABC Arts club";
	void theatreClub();
	void musicClub();

}

interface Gamer extends Recreation{
	void outdoorGames();
	void indoorGames();
}
