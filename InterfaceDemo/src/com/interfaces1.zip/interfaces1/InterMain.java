package com.interfaces1;

public class InterMain {

	public static void main(String[] args) {
		
		InEmployee mgr = new InManager("Tom",10000);
		mgr.getDetails();
		
		BonusCalculator bonusForMgr = (BonusCalculator)mgr;
		bonusForMgr.calculateBonus();
		
		Recreation rec = (Recreation)mgr;
		rec.musicClub();
		rec.theatreClub();
        System.out.println();
        
		InEmployee pgr = new InPgmmr("Tom",10000);
		pgr.getDetails();
		
		BonusCalculator bonusForPgr = (BonusCalculator)pgr;
		bonusForPgr.calculateBonus();
		
		Recreation rec1 = (Recreation)pgr;
		rec1.musicClub();
		rec1.theatreClub();
	
		Gamer gc = (Gamer)pgr;
		gc.indoorGames();
		gc.outdoorGames();
		System.out.println();
		Gamer gr = new Techy();
		gr.indoorGames();
		gr.outdoorGames();
		gr.musicClub();
		gr.theatreClub();
		
	}

}
