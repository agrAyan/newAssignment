package com.interfaces1;

public interface BonusCalculator {
	
	void calculateBonus();

}
