package com.interfaces1;

public class InManager extends InEmployee implements BonusCalculator{


	public InManager(String name, double salary) {
		super(name, salary);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void calculateBonus() {
		System.out.println("Bonus for "+name);
		System.out.println("bonus "+10*salary);
	}

	@Override
	public void musicClub() {
		System.out.println("Music Orchestra by Team members");
	}
	

}
