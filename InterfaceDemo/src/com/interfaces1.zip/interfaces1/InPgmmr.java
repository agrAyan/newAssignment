package com.interfaces1;

public class InPgmmr extends InEmployee implements BonusCalculator,Gamer{

	public InPgmmr(String name, double salary) {
		super(name, salary);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void calculateBonus() {
		System.out.println("Bonus "+5*salary);
	}

	@Override
	public void outdoorGames() {
		System.out.println("cricket club");
	}

	@Override
	public void indoorGames() {
		System.out.println("Chess");
	}

}
