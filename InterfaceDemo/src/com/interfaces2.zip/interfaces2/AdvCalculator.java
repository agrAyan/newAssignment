package com.interfaces2;

public interface AdvCalculator extends Calculator{
	void square();
	

}
