package com.interfaces2;

public class BasicCalc implements Calculator {

	@Override
	public void add(int a, int b) {
	}

	@Override
	public void subtract(int a, int b) {
	}

	@Override
	public void multiply(int a, int b) {
	}

	@Override
	public void divide(int a, int b) {
	}

}
